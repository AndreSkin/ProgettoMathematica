# ProgettoMathematica
Alessio Di Pasquale [0001097535]
Andrea Schinoppi [0001097628]
Andrea Loretti [0001097539]
Luca Donno [0001098545]

Gruppo 1
Corso di Matematica Computazionale, A.A. 2022/2023.


